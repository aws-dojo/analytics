create external schema dojodb_schema from data catalog database 'dojodb' iam_role 'arn:aws:iam::999999999999:role/dojoredshiftrole' create external database if not exists;

SELECT * FROM dojodb_schema.customers;
SELECT * FROM dojodb_schema.sales;

create table customercontacts 
(
customerid int,
customername varchar(100),
email varchar(100),
contactfirstname varchar(100),
contactlastname varchar(100)
)

create table customersales
(
customerid int,
totalsales decimal
)

create table customercities
(
city varchar(100),
customercount int
)

---------------
CREATE OR REPLACE PROCEDURE fillcustomercontacts()
AS $$
BEGIN
delete from public.customercontacts;
insert into public.customercontacts (customerid, customername, email, contactfirstname, contactlastname) select customerid, customername, email, contactfirstname, contactlastname from dojodb_schema.customers;
END
$$ LANGUAGE plpgsql;

------------
CREATE OR REPLACE PROCEDURE fillcustomersales()
AS $$
BEGIN
DELETE FROM public.customersales;
INSERT INTO public.customersales (customerid, totalsales) SELECT customerid, sum(sales) FROM dojodb_schema.sales GROUP BY customerid;
END
$$ LANGUAGE plpgsql;

-------------
CREATE OR REPLACE PROCEDURE fillcustomercities()
AS $$
BEGIN
DELETE FROM public.customercities;
INSERT INTO public.customercities (city, customercount) SELECT city, count(city) FROM dojodb_schema.customers GROUP BY city;
END
$$ LANGUAGE plpgsql;
