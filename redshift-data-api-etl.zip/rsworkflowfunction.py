import json
import boto3
import os

def lambda_handler(event, context):
    source = ""
    state = ""
    
    if event["detail-type"] == "Glue Job State Change":
        source = event["detail"]["jobName"]
    if event["detail-type"] == "Redshift Data Statement Status Change":
        source = event["detail"]["statementName"]
    state = event["detail"]["state"]
    
    ddclient = boto3.client('dynamodb')
    ddresp = ddclient.execute_statement(Statement= "select target, targetsql, targettype from rsstatements where source = '" + source + "'")
    target = ddresp["Items"][0]["target"]["S"]
    targetsql = ddresp["Items"][0]["targetsql"]["S"]
    targettype = ddresp["Items"][0]["targettype"]["S"]
    
    if targettype == "sql" and (state == "FINISHED" or state == "SUCCEEDED"):
        rsclient = boto3.client('redshift-data')
        clusterid = os.environ['REDSHIFT_CLUSTER_ID']
        dbname = os.environ['DATABASE']
        secret = os.environ['SECRETS_ARN']
        rsclient.execute_statement(ClusterIdentifier= clusterid, Database= dbname,SecretArn= secret, Sql= targetsql, StatementName= target, WithEvent= True)
    
    if targettype == "job" and (state == "FINISHED" or state == "SUCCEEDED"):
        glueclient = boto3.client('glue')
        glueclient.start_job_run(JobName=target)