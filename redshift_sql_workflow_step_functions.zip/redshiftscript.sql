CREATE TABLE orders (
  orderNumber int,
  productCode varchar,
  quantityOrdered int,
  priceEach decimal,
  amount decimal
  );

insert  into orders(orderNumber,productCode,quantityOrdered,priceEach,amount) values (10100,'S18_1749',30,136.00,3422.55),(10100,'S18_2248',50,55.09,7332.00),(10100,'S18_4409',22,75.46,5332.12),(10100,'S24_3969',49,35.29,6762.34),(10101,'S18_2325',25,108.06,7332.00),(10101,'S18_2795',26,167.06,2342.42),(10101,'S24_1937',45,32.53,7643.90),(10101,'S24_2022',46,44.35,2334.78),(10102,'S18_1342',39,95.55,7522.88),(10102,'S18_1367',41,43.13,5542.43),(10103,'S10_1949',26,214.30,4322.78);

--------------------
create table ordersummary
(
	orderNumber int,
	totalsales decimal
);
create table productsummary
(
	productCode varchar,
	totalsales decimal
);
create table productquantitysummary
(
	productCode varchar,
	totalquantity decimal
)

---------------
CREATE OR REPLACE PROCEDURE fillordersummary()
AS $$
BEGIN
delete from ordersummary;
insert into ordersummary (orderNumber,totalsales) select orderNumber, sum(amount) from orders group by orderNumber;
END
$$ LANGUAGE plpgsql;

------------------
CREATE OR REPLACE PROCEDURE fillproductsummary()
AS $$
BEGIN
delete from productsummary;
insert into productsummary (productCode,totalsales) select productCode, sum(amount) from orders group by productCode;
END
$$ LANGUAGE plpgsql;

-----------------
------------------
CREATE OR REPLACE PROCEDURE fillproductquantitysummary()
AS $$
BEGIN
delete from productquantitysummary;
insert into productquantitysummary (productCode,totalquantity) select productCode, sum(quantityOrdered) from orders group by productCode;
END
$$ LANGUAGE plpgsql;

-----------------


call fillordersummary();

call fillproductsummary();

call fillproductquantitysummary();

-----------

select count(*) from productquantitysummary;
select count(*) from productsummary;
select count(*) from ordersummary;

------------

delete from productquantitysummary;
delete from productsummary;
delete from ordersummary;