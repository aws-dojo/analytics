import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    client = boto3.client('redshift-data')
    clusterid = '<CLUSTER_ID>'
    db = '<DATABASE_NAME>'
    secrets = '<SECRETS_MANAGER_SECRET>'
    
    sql = event['sql']
    
    response = client.execute_statement(ClusterIdentifier=clusterid, Database=db, SecretArn=secrets, Sql=sql)
    
    return {
        'statusCode': 200,
        'statementid': response['Id']
    }