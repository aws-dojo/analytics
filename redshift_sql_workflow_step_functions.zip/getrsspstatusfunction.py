import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    client = boto3.client('redshift-data')
    stmtid = event['statementid']
    response = client.describe_statement(Id=stmtid)
    return {
        'statusCode': 200,
        'statementid': stmtid,
        'statementStatus': response['Status']
    }