from awsglue.transforms import *

#Customers Tranformation
def tansform(df):
  df = SelectFields.apply(df, paths=['contactfirstname','contactlastname']) 
  return df