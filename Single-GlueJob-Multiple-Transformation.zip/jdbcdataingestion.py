import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

import mytransformation

args = getResolvedOptions(sys.argv, ["JOB_NAME","cdb","ctbl","dest"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

db = args["cdb"]
tbl = args["ctbl"]
dest = args["dest"]

# Script generated for node Amazon Redshift
AmazonRedshift_node1651236431390 = glueContext.create_dynamic_frame.from_catalog(
    database=db,
    redshift_tmp_dir=args["TempDir"],
    table_name=tbl,
    transformation_ctx="AmazonRedshift_node1651236431390",
)

AmazonRedshift_node1651236431390 = mytransformation.tansform(AmazonRedshift_node1651236431390)

# Script generated for node Amazon S3
AmazonS3_node1651236450523 = glueContext.write_dynamic_frame.from_options(
    frame=AmazonRedshift_node1651236431390,
    connection_type="s3",
    format="glueparquet",
    connection_options={"path": dest, "partitionKeys": []},
    format_options={"compression": "snappy"},
    transformation_ctx="AmazonS3_node1651236450523",
)

job.commit()
