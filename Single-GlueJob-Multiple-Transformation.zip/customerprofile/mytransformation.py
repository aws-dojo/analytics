from awsglue.transforms import *

#CustomerProfile Tranformation
def tansform(df):
  df = SelectFields.apply(df, paths=['serviceid','serviceused','age']) 
  return df