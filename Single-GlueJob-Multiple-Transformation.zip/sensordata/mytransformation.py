from awsglue.transforms import *

#SensorData Tranformation
def tansform(df):
  df = SelectFields.apply(df, paths=['deviceid','metric1','metric2','recorddate','failure']) 
  return df