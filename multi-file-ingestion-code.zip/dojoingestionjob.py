import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node PostgreSQL
PostgreSQL_node1641385223738 = glueContext.create_dynamic_frame.from_catalog(
    database="dojodb",
    table_name="postgres_public_employees",
    transformation_ctx="PostgreSQL_node1641385223738",
)

# Script generated for node Amazon S3
AmazonS3_node1641385230761 = glueContext.getSink(
    path="s3://dojo-dataset/employees_raw/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    compression="snappy",
    enableUpdateCatalog=True,
    transformation_ctx="AmazonS3_node1641385230761",
)
AmazonS3_node1641385230761.setCatalogInfo(
    catalogDatabase="dojodb", catalogTableName="employees_raw"
)
AmazonS3_node1641385230761.setFormat("glueparquet")
AmazonS3_node1641385230761.writeFrame(PostgreSQL_node1641385223738)


client = boto3.client('s3')
client.put_object(Body="tokendata", Bucket='dojo-dataset', Key='token/dojocuratedjob')

job.commit()
