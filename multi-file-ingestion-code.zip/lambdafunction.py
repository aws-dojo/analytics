import json
import boto3

def lambda_handler(event, context):
    nexttask = event["Records"][0]["s3"]["object"]["key"]
    glueclient = boto3.client('glue')
    if nexttask == 'token/dojocuratedjob':
        glueclient.start_job_run(JobName='dojocuratedjob')